After unzipping no further installation is necessary. Just click on

IcnirpCalc.exe

and enjoy....

73 Thilo Kootz
tkootz@gmx.de